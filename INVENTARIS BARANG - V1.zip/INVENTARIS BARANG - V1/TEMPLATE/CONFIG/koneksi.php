<?php
      $host = "localhost";
      $username = "root";
      $pass = "";
      $db = "tugasakhir";
      $conn = mysqli_connect($host, $username, $pass, $db);
?>