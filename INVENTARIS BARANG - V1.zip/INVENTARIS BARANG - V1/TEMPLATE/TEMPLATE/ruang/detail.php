<?php
    include "../../CONFIG/KONEKSI.php";
    $id = $_GET['id'];
    $query = "SELECT * FROM ruang WHERE id = $id";
    $exe = mysqli_query($conn, $query);
    $row = mysqli_fetch_array($exe);
 ?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
 </head>
 <body>
 <!DOCTYPE html>
<html lang="en">

<head>

    <title>SB Admin 2 - Tables</title>

    <!-- Custom fonts for this template -->
    <link href="../../BOOTSTRAP/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../../BOOTSTRAP/css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="../../BOOTSTRAP/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
      <!-- Page Wrapper -->
      <div id="wrapper">

<!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../form.php">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text ">Laporan Kerusakan Barang</div>
        </a><hr>

        <hr class="sidebar-divider d-none d-md-block">
    
    <li class="nav-item">
        <a class="nav-link" href="ruang.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Ruang</span></a>
    </li>
    </li>

    <hr class="sidebar-divider d-none d-md-block">
    </ul>
   

    <div id="content-wrapper" class="d-flex flex-column">        
    <?php
        include "../topbar/topbar.php";
    ?>
                <div class="container-fluid">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Daftar Barang Ruangan <?=$row['nama']?></h6>
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Tambah Barang</button>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                            <h5 class="modal-title m-1 font-weight-bold text-primary" id="exampleModalLabel">Tambah Barang</h5>
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <input type="hidden" name = "id_ruang" value = "<?=$id?>"> 
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Kode Barang</th>
                                            <th>Nama Barang</th>
                                            <th>Jenis Barang</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <th>Id</th>
                                        <th>Kode Barang</th>
                                        <th>Nama Barang</th>
                                        <th>Jenis Barang</th>
                                        <th>Aksi</th>
                                    </tfoot>
                                    <tbody>
                                        <?php
                                            include "../../CONFIG/Koneksi.PHP";
                                            $query = "SELECT * FROM inventaris WHERE id_ruang LIKE $id ";
                                            $nomor= 1;
                                            $exe = mysqli_query($conn, $query);
                                            while($row = mysqli_fetch_array($exe)){
                                        ?>
                                        <tr>
                                            <td><?=$nomor++?></td>
                                            <td><?=$row['kode_barang']?></td>
                                            <td><?=$row['nama']?></td> 
                                            <td><?=$row['jenis_barang']?></td> 
                                            <td>
                                                <a href="form_edit_detail.php?id=<?=$row['id']?>&id_ruang=<?=$id?>" class="btn btn-primary btn-circle btn-sm"><i><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                                <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                                <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                                                </svg></i></a>
                                                <a href="sistem/hapus_detail.php?id=<?=$row['id']?>&id_ruang=<?=$id?>" class="btn btn-warning btn-circle btn-sm"><i><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16">
                                                <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5ZM11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H2.506a.58.58 0 0 0-.01 0H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1h-.995a.59.59 0 0 0-.01 0H11Zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5h9.916Zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47ZM8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5Z"/></svg>
                                                </svg></i></a>
                                            </td> 
                                        </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <form action="sistem/tambah_barang.php" method="post" enctype="multipart/form-data">
                                    <input type="hidden" name = "id_ruang" value = "<?=$id?>"> 
                                    <table>
                                        <tr>
                                            <td><span class="badge">Kode Barang</span></td>
                                            <td>:</td>
                                            <td><input type="number" class="form-control" name ="kode_barang"></td>
                                        </tr>
                                        <tr>
                                            <td><span class="badge">Nama Barang</span></td>
                                            <td>:</td>
                                            <td><input type="text" class="form-control" name ="nama"></td>
                                        </tr>
                                        <tr>
                                            <td><span class="badge">Jenis Barang</span></td>
                                            <td>:</td>
                                            <td><select class="form-control" name="jenis_barang">
                                                <option value="elektronik">elektronik</option>
                                                <option value="non-elektronik">non-elektronik</option>
                                                </select></td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <input type="submit" class="btn btn-primary" value="simpan">
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                            </div>         
                        </div>
                    </div>
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>
    

    <!-- Bootstrap core JavaScript-->
    <script src="../../BOOTSTRAP/vendor/jquery/jquery.min.js"></script>
    <script src="../../BOOTSTRAP/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../../BOOTSTRAP/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../../BOOTSTRAP/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="../../BOOTSTRAP/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="../../BOOTSTRAP/vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="../../BOOTSTRAP/js/demo/datatables-demo.js"></script>

</body>

</html>
 </body>
 </html>