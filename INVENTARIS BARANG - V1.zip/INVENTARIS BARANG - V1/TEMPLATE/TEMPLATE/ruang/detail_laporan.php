<?php
    include "../../CONFIG/KONEKSI.php";
    $id = $_GET['id'];
    $query = "SELECT * FROM ruang WHERE id = $id";
    $exe = mysqli_query($conn, $query);
    $row = mysqli_fetch_array($exe);
 ?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
 </head>
 <body>
 <!DOCTYPE html>
<html lang="en">

<head>

    <title>SB Admin 2 - Tables</title>

    <!-- Custom fonts for this template -->
    <link href="../../BOOTSTRAP/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../../BOOTSTRAP/css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="../../BOOTSTRAP/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
      <!-- Page Wrapper -->
      <div id="wrapper">

<!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../form.php">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text ">Laporan Kerusakan Barang</div>
        </a><hr>

        <hr class="sidebar-divider d-none d-md-block">
    
    <li class="nav-item">
        <a class="nav-link" href="ruang.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Ruang</span></a>
    </li>
    </li>

    <hr class="sidebar-divider d-none d-md-block">
    </ul>

    <div id="content-wrapper" class="d-flex flex-column">        
    <?php
        include "../topbar/topbar.php";
    ?>
               <div class="container">

<!-- Portfolio Item Heading -->

<!-- Portfolio Item Row -->
<div class="row">
    <?php
        include "../../CONFIG/Koneksi.PHP";
        $query = "SELECT l.id,i.nama,l.jumlah,l.kondisi,l.tanggal,l.catatan,l.foto FROM laporan_barang l INNER JOIN inventaris i ON l.id_inventaris = i.id WHERE l.id = $id";
        $exe = mysqli_query($conn, $query);
        $row = mysqli_fetch_array($exe);{
    ?>
  <div class="col-md-8">
    <img class="img-fluid" src="../../FOTO/<?=$row['foto']?>" alt="">
  </div>

  <div class="col-md-4">
    <h3 class="my-9"><?=$row['nama']?></h3>
    <ul>
      <li>Jumlah Barang = <?=$row['jumlah']?></li>
      <li>Kondisi Barang = <?=$row['kondisi']?></li>
      <li>Tanggal Laporan = <?=$row['tanggal']?></li>
      <li>Catatan = <?=$row['catatan']?></li>
      
    </ul>
    <?php
    }
    ?>
  </div>

</div>
<!-- /.row -->

<!-- Related Projects Row -->

<!-- /.row -->

</div>
<!-- /.container -->
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>
    

    <!-- Bootstrap core JavaScript-->
    <script src="../../BOOTSTRAP/vendor/jquery/jquery.min.js"></script>
    <script src="../../BOOTSTRAP/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../../BOOTSTRAP/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../../BOOTSTRAP/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="../../BOOTSTRAP/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="../../BOOTSTRAP/vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="../../BOOTSTRAP/js/demo/datatables-demo.js"></script>

</body>

</html>
 </body>
 </html>