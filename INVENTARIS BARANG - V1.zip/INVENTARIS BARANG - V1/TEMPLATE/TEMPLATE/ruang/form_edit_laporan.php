<?php
    include "../../CONFIG/KONEKSI.php";
    $id = $_GET['id'];
    $query = "SELECT * FROM laporan_barang WHERE id = $id";
    $exe = mysqli_query($conn, $query);
    $row = mysqli_fetch_array($exe);
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>SB Admin 2 - Tables</title>
    <link href="../../BOOTSTRAP/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"rel="stylesheet">
    <link href="../../BOOTSTRAP/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="../../BOOTSTRAP/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">
      <div id="wrapper">
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../form.php">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text ">Laporan Kerusakan Barang</div>
        </a><hr>
        <hr class="sidebar-divider d-none d-md-block">
    <li class="nav-item">
        <a class="nav-link" href="ruang.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Ruang</span></a>
    </li>
    <hr class="sidebar-divider d-none d-md-block">
    </ul>
    <div id="content-wrapper" class="d-flex flex-column">       
    <?php
        include "../topbar/topbar.php";
    ?>
    <center><div class="card mb-2 py-1 border-left-primary" style="width: 30rem; margin: 10px;">
                 <div class="card-header py-2">
                    <h6 class="m-0 font-weight-bold text-primary">Edit Barang</h6>
                </div>
                <div class="card-body">
                    <form action="sistem/edit_laporan.php" method="post">
                    <input type="hidden" name = "id" value = "<?=$row['id']?>">
                    <input type="hidden" name = "id_ruang" value = "<?=$row['id_ruang']?>">  
                        <table>
                            <tr>
                                <td><span class="badge">Kondisi barang</span></td>
                                <td>:</td>
                                <td><select name="kondisi" id="" class="form-control">
                                    <option value="sedang">Sedang</option>
                                    <option value="berat">berat</option>
                                </select></td>
                            </tr>
                            <tr>
                                <td><span class="badge">Jumlah</span></td>
                                <td>:</td>
                                <td><input type = "number" class="form-control" name ="jumlah" value="<?=$row['jumlah']?>"></td>
                            </tr>
                            <tr>
                                <td><span class="badge">Tanggal</span></td>
                                <td>:</td>
                                <td><input type = "date" class="form-control" name ="tanggal" value="<?=$row['tanggal']?>"></td></td>
                            </tr>
                            <tr>
                                <td><span class="badge">Catatan</span></td>
                                <td>:</td>
                                <td><input type = "text" class="form-control" name ="catatan" value="<?=$row['catatan']?>"></td></td>
                            </tr>
                            <tr>
                                <td>
                                <input type="submit" class="btn btn-primary" value="simpan" style="margin-top: 15px;">
                                </td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>
        </center>        


    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>
    

    <script src="../../BOOTSTRAP/vendor/jquery/jquery.min.js"></script>
    <script src="../../BOOTSTRAP/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../../BOOTSTRAP/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="../../BOOTSTRAP/js/sb-admin-2.min.js"></script>
    <script src="../../BOOTSTRAP/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="../../BOOTSTRAP/vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="../../BOOTSTRAP/js/demo/datatables-demo.js"></script>

</body>

</html>
