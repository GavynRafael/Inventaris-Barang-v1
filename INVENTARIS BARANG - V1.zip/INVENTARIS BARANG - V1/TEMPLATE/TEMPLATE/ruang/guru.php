<?php
    include "../../CONFIG/KONEKSI.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>SB Admin 2 - Tables</title>

    <!-- Custom fonts for this template -->
    <link href="../../BOOTSTRAP/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../../BOOTSTRAP/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="../../BOOTSTRAP/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
      <!-- Page Wrapper -->
      <div id="wrapper">

<!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../form.php">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text ">Laporan Kerusakan Barang</div>
        </a><hr>

        <hr class="sidebar-divider d-none d-md-block">
    
    <li class="nav-item">
        <a class="nav-link" href="ruang.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Ruangan</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="guru.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Guru</span></a>
    </li>
    <hr class="sidebar-divider d-none d-md-block">
    </ul>
    <div id="content-wrapper" class="d-flex flex-column">          
    <?php
        include "../topbar/topbar.php";
    ?>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-1 font-weight-bold text-primary">Data Guru</h6>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Tambah Guru</button>
                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title m-1 font-weight-bold text-primary " id="exampleModalLabel">Tambah Ruang</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form action="sistem/tambah_guru.php" method="post">
                                    <input type="hidden" name = "id"> 
                                    <table>
                                        <tr>
                                            <td><span class="badge">Nik</span></td>
                                            <td>:</td>
                                            <td><input type="text" class="form-control" name ="nik"></td>
                                        </tr>
                                        <tr>
                                            <td><span class="badge">Nama Guru</span></td>
                                            <td>:</td>
                                            <td><input type="text" class="form-control" name ="nama_guru"></td>
                                        </tr>
                                        <tr>
                                            <td><span class="badge">Username</span></td>
                                            <td>:</td>
                                            <td><input class="form-control" name="username"></td>
                                        </tr>
                                        <tr>
                                            <td><span class="badge">Password</span></td>
                                            <td>:</td>
                                            <td><input class="form-control" name="password"></td>
                                        </tr>
                                        <tr>
                                            <td><span class="badge">Email</span></td>
                                            <td>:</td>
                                            <td><input class="form-control" name="email"></td>
                                        </tr>
                                        <tr>
                                            <td><span class="badge">No hp</span></td>
                                            <td>:</td>
                                            <td><input class="form-control" name="no_hp"></td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <input type="submit" class="btn btn-primary" value="simpan">
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                            </div>         
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nik</th>
                                    <th>Nama Guru</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ID</th>
                                    <th>Nik</th>
                                    <th>Nama Guru</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php
                                    include "../../CONFIG/Koneksi.PHP";
                                    $query = " SELECT * FROM guru";
                                    $exe = mysqli_query($conn, $query);
                                    $nomor = 1;
                                    while($row = mysqli_fetch_array($exe)){
                                ?>
                                <tr>
                                    <td><?=$nomor++?></td>
                                    <td><?=$row['nik']?></td>
                                    <td><?=$row['nama_guru']?></td> 
                                </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>
    
    <script src="../../BOOTSTRAP/vendor/jquery/jquery.min.js"></script>
    <script src="../../BOOTSTRAP/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src=../../BOOTSTRAP/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../../BOOTSTRAP/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="../../BOOTSTRAP/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="../../BOOTSTRAP/vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="../../BOOTSTRAP/js/demo/datatables-demo.js"></script>
    

</body>

</html>