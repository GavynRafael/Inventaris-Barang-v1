<?php
    include "../../CONFIG/KONEKSI.php";
    session_start();
    if ($_SESSION['status'] != "login") {
        # code...
       echo "<script>alert('Anda harus login terlebih dahulu'); document.location.href = '../../index.php'</script>";
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>SB Admin 2 - Tables</title>

    <!-- Custom fonts for this template -->
    <link href="../../BOOTSTRAP/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../../BOOTSTRAP/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="../../BOOTSTRAP/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
      <!-- Page Wrapper -->
      <div id="wrapper">

<!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../form.php">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text ">Laporan Kerusakan Barang</div>
        </a><hr>

        <hr class="sidebar-divider d-none d-md-block">
    
    <li class="nav-item">
        <a class="nav-link" href="ruang.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Ruangan</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="guru.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Guru</span></a>
    </li>
    <hr class="sidebar-divider d-none d-md-block">
    </ul>
    <div id="content-wrapper" class="d-flex flex-column">          
    <?php
        include "../topbar/topbar.php";
    ?>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-1 font-weight-bold text-primary">Ruangan</h6>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Tambah Ruang</button>
                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title m-1 font-weight-bold text-primary " id="exampleModalLabel">Tambah Ruang</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form action="sistem/tambah_ruang.php" method="post">
                                    <input type="hidden" name = "id"> 
                                    <table>
                                        <tr>
                                            <td><span class="badge">Nama Ruang</span></td>
                                            <td>:</td>
                                            <td><input type="text" class="form-control" name ="nama"></td>
                                        </tr>
                                        <tr>
                                            <td><span class="badge">Keterangan</span></td>
                                            <td>:</td>
                                            <td><input type="text" class="form-control" name ="keterangan"></td>
                                        </tr>
                                        <tr>
                                            <td><span class="badge">Nama Guru</span></td>
                                            <td>:</td>
                                            <td><select class="form-control" name="id_guru">
                                                <?php
                                                    include "../../CONFIG/KONEKSI.php";
                                                    $query = "SELECT * FROM guru";
                                                    $exe = mysqli_query($conn, $query);
                                                    while($row = mysqli_fetch_array($exe)){
                                                ?>
                                                <option value="<?=$row['id']?>"><?=$row['nama_guru']?></option>
                                                <?php
                                                    }
                                                ?>
                                                </select></td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <input type="submit" class="btn btn-primary" value="simpan">
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                            </div>         
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nama Ruangan</th>
                                    <th>Pengawas Ruangan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <th>ID</th>
                                <th>Nama Ruangan</th>
                                <th>Pengawas Ruangan</th>
                                <th>Aksi</th>
                            </tfoot>
                            <tbody>
                                <?php
                                    include "../../CONFIG/Koneksi.PHP";
                                    $guru_id = $_SESSION['id'];
                                    $query = " SELECT r.id, r.nama, u.nama_guru FROM ruang r INNER JOIN guru u ON r.id_guru = u.id WHERE r.id_guru = $guru_id";
                                    $exe = mysqli_query($conn, $query);
                                    $nomor = 1;
                                    while($row = mysqli_fetch_array($exe)){
                                ?>
                                <tr>
                                    <td><?=$nomor++?></td>
                                    <td><?=$row['nama']?></td>
                                    <td><?=$row['nama_guru']?></td> 
                                    <td>
                                        <a href="detail.php?id=<?=$row['id']?>" class="btn btn-primary btn-circle btn-sm"><i><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-binoculars" viewBox="0 0 16 16" data-toggle="modal" data-target="#exampleModal">
                                        <path d="M3 2.5A1.5 1.5 0 0 1 4.5 1h1A1.5 1.5 0 0 1 7 2.5V5h2V2.5A1.5 1.5 0 0 1 10.5 1h1A1.5 1.5 0 0 1 13 2.5v2.382a.5.5 0 0 0 .276.447l.895.447A1.5 1.5 0 0 1 15 7.118V14.5a1.5 1.5 0 0 1-1.5 1.5h-3A1.5 1.5 0 0 1 9 14.5v-3a.5.5 0 0 1 .146-.354l.854-.853V9.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v.793l.854.853A.5.5 0 0 1 7 11.5v3A1.5 1.5 0 0 1 5.5 16h-3A1.5 1.5 0 0 1 1 14.5V7.118a1.5 1.5 0 0 1 .83-1.342l.894-.447A.5.5 0 0 0 3 4.882V2.5zM4.5 2a.5.5 0 0 0-.5.5V3h2v-.5a.5.5 0 0 0-.5-.5h-1zM6 4H4v.882a1.5 1.5 0 0 1-.83 1.342l-.894.447A.5.5 0 0 0 2 7.118V13h4v-1.293l-.854-.853A.5.5 0 0 1 5 10.5v-1A1.5 1.5 0 0 1 6.5 8h3A1.5 1.5 0 0 1 11 9.5v1a.5.5 0 0 1-.146.354l-.854.853V13h4V7.118a.5.5 0 0 0-.276-.447l-.895-.447A1.5 1.5 0 0 1 12 4.882V4h-2v1.5a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5V4zm4-1h2v-.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5V3zm4 11h-4v.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5V14zm-8 0H2v.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5V14z"/>
                                        </svg></i></a>
                                        <a href="barang.php?id=<?=$row['id']?>" class="btn btn-info btn-circle btn-sm"><i><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-folder" viewBox="0 0 16 16">
                                        <path d="M.54 3.87.5 3a2 2 0 0 1 2-2h3.672a2 2 0 0 1 1.414.586l.828.828A2 2 0 0 0 9.828 3h3.982a2 2 0 0 1 1.992 2.181l-.637 7A2 2 0 0 1 13.174 14H2.826a2 2 0 0 1-1.991-1.819l-.637-7a1.99 1.99 0 0 1 .342-1.31zM2.19 4a1 1 0 0 0-.996 1.09l.637 7a1 1 0 0 0 .995.91h10.348a1 1 0 0 0 .995-.91l.637-7A1 1 0 0 0 13.81 4H2.19zm4.69-1.707A1 1 0 0 0 6.172 2H2.5a1 1 0 0 0-1 .981l.006.139C1.72 3.042 1.95 3 2.19 3h5.396l-.707-.707z"/>
                                        </svg></i></a>
                                        <a href="tambah.php?id=<?=$row['id']?>" class="btn btn-warning btn-circle btn-sm"><i><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-circle" viewBox="0 0 16 16">
                                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                        <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                                        </svg></i></a>
                                    </td> 
                                </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>
    
    <script src="../../BOOTSTRAP/vendor/jquery/jquery.min.js"></script>
    <script src="../../BOOTSTRAP/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src=../../BOOTSTRAP/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../../BOOTSTRAP/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="../../BOOTSTRAP/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="../../BOOTSTRAP/vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="../../BOOTSTRAP/js/demo/datatables-demo.js"></script>
    

</body>

</html>