<?php
    include "../../../config/koneksi.php";

    $id = $_POST['id'];
    $id_ruang = $_POST['id_ruang'];
    $kbarang = $_POST['kode_barang'];
    $nbarang = $_POST['nama'];
    $jbarang = $_POST['jenis_barang'];
    
    
    $query = "UPDATE inventaris SET kode_barang = '$kbarang', nama = '$nbarang', jenis_barang = '$jbarang' WHERE id = $id";
    $exe = mysqli_query($conn, $query);
    if ($exe) {
        echo "<script>alert('Tambah Data Berhasil'); document.location.href = '../detail.php?id=".$id_ruang."';</script>";
    }else{
        echo "<script>alert('Proses Ubah Data Gagal'); document.location.href = '../detail.php?id=".$id_ruang."';</script>";
 
    }
?>

