<?php
    include "../../../config/koneksi.php";
    $id = $_POST['id'];
    $id_ruang = $_POST['id_ruang'];
    $kbarang = $_POST['kondisi'];
    $tanggal = $_POST['tanggal'];
    $jbarang = $_POST['jumlah'];
    $catatan = $_POST['catatan'];
    
    
    $query = "UPDATE laporan_barang SET kondisi = '$kbarang', jumlah = '$jbarang', tanggal = '$tanggal',catatan = '$catatan' WHERE id = $id";
    $exe = mysqli_query($conn, $query);
    if ($exe) {
        echo "<script>alert('Proses Ubah Data Berhasil'); document.location.href = '../barang.php?id=".$id_ruang."'</script>";
    }else{
        echo "<script>alert('Proses Ubah Data Gagal'); document.location.href = '../barang.php?id=".$id_ruang."'</script>";
 
    }
?>