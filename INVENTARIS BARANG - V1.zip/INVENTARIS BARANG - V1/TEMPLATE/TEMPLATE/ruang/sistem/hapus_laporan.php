<?php
 include "../../../config/koneksi.php";
 $id = $_GET['id'];
 $id_ruang = $_GET['id_ruang'];
 $query = "DELETE FROM laporan_barang WHERE id = $id";
 $exe = mysqli_query($conn, $query);
 if ($exe) {
     echo "<script>alert('Proses Hapus Data Berhasil'); document.location.href = '../barang.php?id=".$id_ruang."'</script>";
 }else{
     echo "<script>alert('Proses Hapus Data Gagal'); document.location.href = '../barang.php?id=".$id_ruang."'</script>";

 }
?>
