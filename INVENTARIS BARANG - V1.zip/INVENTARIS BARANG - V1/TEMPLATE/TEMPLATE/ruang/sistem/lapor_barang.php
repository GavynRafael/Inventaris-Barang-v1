<?php
    include "../../../CONFIG/koneksi.php";
    $id_ruang = $_POST['id_ruang'];
    $id_inventaris = $_POST['id_inventaris'];
    $jbarang = $_POST['jumlah'];
    $tanggal = $_POST['tanggal'];
    $kbarang = $_POST['kondisi'];  
    $catatan = $_POST['catatan'];  

    $ekstensi_diperbolehkan	= array('png','jpg','jpeg');
    $foto = $_FILES['foto']['name'];
    $x = explode('.', $foto);
    $ekstensi = strtolower(end($x));
    $ukuran	= $_FILES['foto']['size'];
    $file_tmp = $_FILES['foto']['tmp_name'];
    
    if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
        if($ukuran < 10044070){			
            move_uploaded_file($file_tmp, '../../../FOTO/'.$foto);
        $query = "INSERT INTO laporan_barang VALUES(null, '$kbarang', '$jbarang', '$tanggal', '$foto', '$catatan', $id_inventaris, $id_ruang)"; 
        $exe = mysqli_query($conn, $query);
        
        if ($exe) {
            echo "<script>alert('Tambah Data Berhasil'); document.location.href = '../ruang.php';</script>";
        }else{
            echo "<script>alert('Tambah Data Gagal'); document.location.href = '../ruang.php';</script>";
        }
          
        }else{
            echo 'UKURAN FOTO TERLALU BESAR';
        }
    }else{
        echo 'EKSTENSI FOTO YANG DI UPLOAD TIDAK DI PERBOLEHKAN';
    }
 ?>