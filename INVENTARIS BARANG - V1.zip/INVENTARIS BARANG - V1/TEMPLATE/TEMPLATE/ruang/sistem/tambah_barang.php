<?php
    include "../../../CONFIG/koneksi.php";
    $kbarang = $_POST['kode_barang'];
    $nbarang = $_POST['nama'];
    $rbarang = $_POST['id_ruang'];
    $jbarang = $_POST['jenis_barang'];



    $query = "INSERT INTO inventaris VALUES (null, '$kbarang', '$nbarang', '$jbarang', $rbarang);";
        $exe = mysqli_query($conn, $query);

        if ($exe) {
            echo "<script>alert('Tambah Data Berhasil'); document.location.href = '../detail.php?id=".$rbarang."';</script>";
        }else{
            echo "<script>alert('Tambah Data Gagal'); document.location.href = '../ruang.php';</script>";
        }

?>