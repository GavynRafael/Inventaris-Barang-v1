<?php
    include "../../../CONFIG/koneksi.php";
    $nguru = $_POST['nama_guru'];
    $nik = $_POST['nik'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $nohp = $_POST['no_hp'];


    $query = "INSERT INTO guru VALUES (null, '$nguru',$nik,'$username','$password','$email',$nohp);";
        $exe = mysqli_query($conn, $query);

        if ($exe) {
            echo "<script>alert('Tambah Data Berhasil'); document.location.href = '../guru.php';</script>";
        }else{
            echo "<script>alert('Tambah Data Gagal'); document.location.href = '../guru.php';</script>";
        }
           
?>