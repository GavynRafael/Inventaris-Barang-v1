<?php
    include "../../../CONFIG/koneksi.php";
    $nruang = $_POST['nama'];
    $kruang = $_POST['keterangan'];
    $rruang = $_POST['id_guru'];


    $query = "INSERT INTO ruang VALUES (null, '$nruang', '$kruang', $rruang);";
        $exe = mysqli_query($conn, $query);

        if ($exe) {
            echo "<script>alert('Tambah Data Berhasil'); document.location.href = '../ruang.php';</script>";
        }else{
            echo "<script>alert('Tambah Data Gagal'); document.location.href = '../ruang.php';</script>";
        }

?>