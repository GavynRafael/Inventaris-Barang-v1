<?php
    include 'CONFIG/koneksi.php';
 
    $username = $_POST['username'];
    $password = $_POST['password'];
     

    $login = mysqli_query($conn,"SELECT * from guru where username='$username' and password='$password'");
    $data = mysqli_fetch_array($login);
    $cek = mysqli_num_rows($login);
    if($cek > 0){
        session_start();
        $_SESSION['id'] = $data['id'];
        $_SESSION['nama'] = $data['nama'];
        $_SESSION['username'] = $username;
        $_SESSION['status'] = "login";
        header("location:TEMPLATE/form.php");
    }else{
        echo "<script>alert('Username / Password salah'); document.location.href = 'index.php';</script>";
        
    }
?>
