-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 06 Des 2022 pada 15.16
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tugasakhir`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `guru`
--

CREATE TABLE `guru` (
  `id` int(11) NOT NULL,
  `nama_guru` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `nik` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(50) CHARACTER SET macce COLLATE macce_bin NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `no_hp` varchar(15) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=swe7;

--
-- Dumping data untuk tabel `guru`
--

INSERT INTO `guru` (`id`, `nama_guru`, `nik`, `username`, `password`, `email`, `no_hp`) VALUES
(1, 'Saifudin', '617283749184716', 'saifudin', '123', 'saifudin@gmail.com', '08923746112'),
(2, 'Bachrudin', '35767890765433433', 'bachrudin', '123', 'bachrudin@gmail.com', '086123561721'),
(3, 'arvin', '18276389016345733', 'arvin', '123', 'evos@gmail.com', '0861235616511'),
(4, 'dzaky', '9734251668903765', 'dzaky\r\n', '123', 'dzakys@gmail.com', '0861235618632'),
(5, 'danu', '4537892065134567', 'danu', '123', 'danu@gmail.com', '0861235618662'),
(15, 'Bambang', '8201152515262', 'bambang', '123', 'bambang@gmail.com', '854726123773');

-- --------------------------------------------------------

--
-- Struktur dari tabel `inventaris`
--

CREATE TABLE `inventaris` (
  `id` int(11) NOT NULL,
  `kode_barang` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `jenis_barang` enum('elektronik','non-elektronik') NOT NULL,
  `id_ruang` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `inventaris`
--

INSERT INTO `inventaris` (`id`, `kode_barang`, `nama`, `jenis_barang`, `id_ruang`) VALUES
(10, '123456789', 'Televisi', 'elektronik', 1),
(11, '123456788', 'Ac', 'elektronik', 1),
(12, '9812346173', 'Meja', 'non-elektronik', 1),
(13, '1242345678', 'Kursi', 'non-elektronik', 1),
(15, '7261536782', 'Papan Tulis', 'non-elektronik', 2),
(17, '261274839', 'Meja', 'non-elektronik', 2),
(18, '298109993', 'kursi', 'non-elektronik', 2),
(19, '382001235', 'kipas angin', 'elektronik', 2),
(21, '22874009', 'AC', 'elektronik', 3),
(22, '003376519', 'kursi bakso', 'non-elektronik', 3),
(23, '336778901', 'LED', 'elektronik', 3),
(24, '774409829', 'lampu', 'elektronik', 3),
(25, '377209814', 'StopKontak', 'elektronik', 3),
(26, '092157833', 'meja', 'non-elektronik', 4),
(27, '004477832', 'AC', 'elektronik', 4),
(28, '094652183', 'Kursi', 'non-elektronik', 4),
(29, '003218834', 'PC', 'elektronik', 4),
(30, '857632247', 'mouse', 'elektronik', 4),
(31, '7453288341', 'Monitor', 'elektronik', 5),
(32, '094773221', 'AC', 'elektronik', 5),
(33, '332511430', 'lampu', 'elektronik', 5),
(34, '113342341', 'LAN', 'elektronik', 5),
(35, '309821232', 'Meja', 'non-elektronik', 5),
(36, '362220098', 'StopKontak', 'elektronik', 6),
(37, '320098761', 'Meja', 'non-elektronik', 6),
(38, '033298764', 'Kursi', 'non-elektronik', 6),
(39, '098321898', 'PC', 'elektronik', 6),
(40, '048756372', 'Monitor', 'elektronik', 6),
(41, '120938745', 'PC', 'non-elektronik', 7),
(42, '463092874', 'Monitor', 'elektronik', 7),
(43, '320933764', 'Mouse', 'elektronik', 7),
(44, '332109824', 'AC', 'elektronik', 7),
(45, '009333621', 'Meja', 'non-elektronik', 7),
(46, '774453220', 'AC', 'elektronik', 8),
(47, '220931732', 'Meja', 'non-elektronik', 8),
(52, '123615273', 'Meja', 'non-elektronik', 19),
(53, '1245534634', 'Televisi', 'elektronik', 19),
(54, '8192837627', 'Lampu', 'elektronik', 2),
(55, '4526172839', 'Kursi', 'non-elektronik', 20),
(57, '1234522345', 'Ac', 'elektronik', 22),
(58, '182739182', 'Lemari', 'non-elektronik', 1),
(60, '3452213459', 'Meja', 'non-elektronik', 23),
(61, '9817362784', 'AC', 'non-elektronik', 23),
(62, '4253617392', 'Kipas Angin', 'elektronik', 24),
(63, '6583128371', 'Meja', 'non-elektronik', 24),
(66, '8749182731', 'Proyektor', 'elektronik', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `laporan_barang`
--

CREATE TABLE `laporan_barang` (
  `id` int(11) NOT NULL,
  `kondisi` enum('sedang','berat') NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `foto` text NOT NULL,
  `catatan` text DEFAULT NULL,
  `id_inventaris` int(11) DEFAULT NULL,
  `id_ruang` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `laporan_barang`
--

INSERT INTO `laporan_barang` (`id`, `kondisi`, `jumlah`, `tanggal`, `foto`, `catatan`, `id_inventaris`, `id_ruang`) VALUES
(22, 'berat', 3, '2022-12-03', 'space-stars-black-hole-uhdpaper.com-4K-4.758.jpg', '123', 66, 1),
(23, 'sedang', 3, '2022-12-07', 'wallpaperflare.com_wallpaper.jpg', 'Kursi rusak\r\n', 18, 2),
(24, 'berat', 1, '2022-12-04', 'relasi3.png', 'Led rusak\r\n', 23, 3),
(25, 'sedang', 4, '2022-12-04', 'sun.jpg', 'Stop kontak rusak', 36, 6);

-- --------------------------------------------------------

--
-- Struktur dari tabel `ruang`
--

CREATE TABLE `ruang` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `id_guru` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `ruang`
--

INSERT INTO `ruang` (`id`, `nama`, `keterangan`, `id_guru`) VALUES
(1, 'A1', 'Ruangan A1', 1),
(2, 'A2', 'Ruangan A2', 1),
(3, 'A3', 'Ruangan A3', 1),
(4, 'B1', 'Ruangan B1', 2),
(5, 'B2', 'Ruangan B2', 2),
(6, 'B3', 'Ruangan B3', 2),
(7, 'C1', 'Ruangan C1', 3),
(8, 'C2', 'Ruangan C2', 3),
(9, 'C3', 'Ruangan C3', 3),
(10, 'D1', 'Ruangan D1', 4),
(19, 'F1', 'Ruangan F1\r\n', 15),
(20, 'F2', 'Ruangan F2', 15),
(22, 'F3', 'Ruangan F3', 15),
(23, 'D2', 'Ruangan D2', 4),
(24, 'D3', 'Ruangan D3', 4),
(25, 'E1', 'Ruangan E1', 5),
(26, 'E2', 'Ruangan E2', 5),
(27, 'E3', 'Ruangan E3', 5);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `inventaris`
--
ALTER TABLE `inventaris`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_ruang` (`id_ruang`);

--
-- Indeks untuk tabel `laporan_barang`
--
ALTER TABLE `laporan_barang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_inventaris` (`id_inventaris`),
  ADD KEY `id_ruang` (`id_ruang`);

--
-- Indeks untuk tabel `ruang`
--
ALTER TABLE `ruang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ruang_ibfk_1` (`id_guru`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `guru`
--
ALTER TABLE `guru`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `inventaris`
--
ALTER TABLE `inventaris`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT untuk tabel `laporan_barang`
--
ALTER TABLE `laporan_barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT untuk tabel `ruang`
--
ALTER TABLE `ruang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `inventaris`
--
ALTER TABLE `inventaris`
  ADD CONSTRAINT `inventaris_ibfk_1` FOREIGN KEY (`id_ruang`) REFERENCES `ruang` (`id`),
  ADD CONSTRAINT `inventaris_ibfk_2` FOREIGN KEY (`id_ruang`) REFERENCES `ruang` (`id`);

--
-- Ketidakleluasaan untuk tabel `laporan_barang`
--
ALTER TABLE `laporan_barang`
  ADD CONSTRAINT `laporan_barang_ibfk_1` FOREIGN KEY (`id_inventaris`) REFERENCES `inventaris` (`id`),
  ADD CONSTRAINT `laporan_barang_ibfk_2` FOREIGN KEY (`id_ruang`) REFERENCES `ruang` (`id`);

--
-- Ketidakleluasaan untuk tabel `ruang`
--
ALTER TABLE `ruang`
  ADD CONSTRAINT `ruang_ibfk_1` FOREIGN KEY (`id_guru`) REFERENCES `guru` (`id`) ON DELETE SET NULL ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
